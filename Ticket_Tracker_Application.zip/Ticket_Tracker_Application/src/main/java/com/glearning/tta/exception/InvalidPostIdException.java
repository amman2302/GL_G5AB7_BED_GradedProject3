package com.glearning.tta.exception;

 
public class InvalidPostIdException extends RuntimeException {

		/**
	 * 
	 */
	private static final long serialVersionUID = -8616490441248039408L;

		public InvalidPostIdException(String message) {
			super(message);
		}
}